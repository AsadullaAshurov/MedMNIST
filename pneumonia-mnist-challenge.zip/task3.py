import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
import medmnist
from medmnist import INFO
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import cosine_similarity

def get_encoder():
    from task1 import get_resnet18
    model = get_resnet18()
    model.load_state_dict(torch.load('resnet18_pneumonia.pth'))
    # Use penultimate layer as feature extractor
    encoder = nn.Sequential(*(list(model.children())[:-1]))
    return encoder

def extract_features(model, loader, device):
    model.eval()
    features = []
    labels = []
    with torch.no_grad():
        for imgs, targets in loader:
            imgs = imgs.to(device).float()
            feat = model(imgs)
            feat = feat.view(feat.size(0), -1)
            features.append(feat.cpu().numpy())
            labels.append(targets.numpy())
    return np.concatenate(features), np.concatenate(labels)

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[.5], std=[.5])
    ])
    
    data_flag = 'pneumoniamnist'
    info = INFO[data_flag]
    DataClass = getattr(medmnist, info['python_class'])
    
    train_dataset = DataClass(split='train', transform=transform, download=True)
    test_dataset = DataClass(split='test', transform=transform, download=True)
    
    train_loader = DataLoader(train_dataset, batch_size=128, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False)
    
    encoder = get_encoder().to(device)
    
    print("Extracting features from train and test sets...")
    train_features, train_labels = extract_features(encoder, train_loader, device)
    test_features, test_labels = extract_features(encoder, test_loader, device)
    
    # Retrieval example
    query_idx = 0
    query_feat = test_features[query_idx].reshape(1, -1)
    query_label = test_labels[query_idx][0]
    
    # Calculate cosine similarity with all train features
    similarities = cosine_similarity(query_feat, train_features).flatten()
    
    # Get top 5 most similar images
    top_k_indices = similarities.argsort()[-5:][::-1]
    
    # Visualize
    fig, axes = plt.subplots(1, 6, figsize=(18, 3))
    
    # Query image
    q_img, _ = test_dataset[query_idx]
    axes[0].imshow(q_img[0], cmap='gray')
    axes[0].set_title(f"Query (L:{query_label})")
    axes[0].axis('off')
    
    for i, idx in enumerate(top_k_indices):
        img, _ = train_dataset[idx]
        sim = similarities[idx]
        label = train_labels[idx][0]
        axes[i+1].imshow(img[0], cmap='gray')
        axes[i+1].set_title(f"Sim: {sim:.2f} (L:{label})")
        axes[i+1].axis('off')
        
    plt.savefig('retrieval_results.png')
    print("Saved retrieval_results.png")

if __name__ == "__main__":
    main()

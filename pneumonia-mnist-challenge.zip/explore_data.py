import medmnist
from medmnist import INFO, Evaluator
import matplotlib.pyplot as plt
import numpy as np

def explore_data():
    data_flag = 'pneumoniamnist'
    info = INFO[data_flag]
    DataClass = getattr(medmnist, info['python_class'])

    # load the data
    train_dataset = DataClass(split='train', download=True)
    test_dataset = DataClass(split='test', download=True)

    print(f"Data info: {info}")
    print(f"Train dataset size: {len(train_dataset)}")
    print(f"Test dataset size: {len(test_dataset)}")

    # Visualize some samples
    fig, axes = plt.subplots(1, 5, figsize=(15, 3))
    for i in range(5):
        img, target = train_dataset[i]
        axes[i].imshow(img, cmap='gray')
        axes[i].set_title(f"Label: {target[0]} ({info['label'][str(target[0])]})")
        axes[i].axis('off')
    plt.savefig('data_samples.png')
    print("Saved data_samples.png")

if __name__ == "__main__":
    explore_data()

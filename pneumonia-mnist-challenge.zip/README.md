# PneumoniaMNIST Challenge

This repository contains the solution for the PneumoniaMNIST Medical Imaging Challenge.

## Tasks
1. **CNN Classification**: A ResNet-18 model trained to classify pneumonia vs normal chest X-rays. Includes Grad-CAM for interpretability.
2. **Medical Report Generation**: An Encoder-Decoder (CNN + GRU) architecture that generates descriptive medical reports.
3. **Semantic Image Retrieval**: A system that finds visually similar cases in the dataset using deep feature embeddings.

## Files
- `pneumonia_mnist_challenge.ipynb`: Comprehensive Google Colab-ready notebook.
- `task1.py`: CNN Classification script.
- `task2.py`: Medical Report Generation script.
- `task3.py`: Semantic Image Retrieval script.
- `explore_data.py`: Initial data exploration script.

## How to Run
### Using Google Colab (Recommended)
Upload `pneumonia_mnist_challenge.ipynb` to Google Colab and run all cells.

### Locally
1. Install dependencies:
   ```bash
   pip install medmnist torch torchvision matplotlib scikit-learn captum
   ```
2. Run any of the task scripts or the notebook:
   ```bash
   python task1.py
   python task2.py
   python task3.py
   ```

## Results
The classification model achieves ~0.94 AUC on the test set. Grad-CAM visualizations show the model focuses on the lung regions for its predictions. The retrieval system successfully finds similar medical cases based on learned features.

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset
import torchvision.models as models
import medmnist
from medmnist import INFO
import numpy as np
import random

# Reuse the model from Task 1
def get_resnet_encoder():
    from task1 import get_resnet18
    model = get_resnet18()
    # Load trained weights
    model.load_state_dict(torch.load('resnet18_pneumonia.pth'))
    # Remove the FC layer
    encoder = nn.Sequential(*(list(model.children())[:-1]))
    return encoder

class ReportDataset(Dataset):
    def __init__(self, split='train', transform=None):
        data_flag = 'pneumoniamnist'
        info = INFO[data_flag]
        DataClass = getattr(medmnist, info['python_class'])
        self.dataset = DataClass(split=split, transform=transform, download=True)
        
        self.reports_normal = [
            "The lungs are clear. No evidence of pneumonia.",
            "Normal chest X-ray. No consolidations found.",
            "The heart size is normal. Lungs are well-expanded and clear."
        ]
        self.reports_pneumonia = [
            "Opacities observed in the lungs, consistent with pneumonia.",
            "Bilateral consolidations found. Findings suggest pneumonia.",
            "Patchy opacities in both lung fields. Findings suggest pneumonia."
        ]
        
        # Build vocabulary
        self.vocab = {"<PAD>": 0, "<SOS>": 1, "<EOS>": 2, "<UNK>": 3}
        all_text = " ".join(self.reports_normal + self.reports_pneumonia)
        words = sorted(list(set(all_text.replace(".", "").lower().split())))
        for i, word in enumerate(words):
            self.vocab[word] = i + 4
        self.inv_vocab = {v: k for k, v in self.vocab.items()}
        
    def tokenize(self, text):
        tokens = [self.vocab["<SOS>"]]
        for word in text.replace(".", "").lower().split():
            tokens.append(self.vocab.get(word, self.vocab["<UNK>"]))
        tokens.append(self.vocab["<EOS>"])
        return torch.tensor(tokens)

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img, target = self.dataset[idx]
        label = target[0]
        if label == 0:
            report = random.choice(self.reports_normal)
        else:
            report = random.choice(self.reports_pneumonia)
        
        tokenized_report = self.tokenize(report)
        return img, tokenized_report

def collate_fn(batch):
    imgs, reports = zip(*batch)
    imgs = torch.stack(imgs)
    lengths = [len(r) for r in reports]
    padded_reports = nn.utils.rnn.pad_sequence(reports, batch_first=True, padding_value=0)
    return imgs, padded_reports, torch.tensor(lengths)

class DecoderRNN(nn.Module):
    def __init__(self, embed_size, hidden_size, vocab_size, num_layers=1):
        super(DecoderRNN, self).__init__()
        self.embed = nn.Embedding(vocab_size, embed_size)
        self.gru = nn.GRU(embed_size, hidden_size, num_layers, batch_first=True)
        self.linear = nn.Linear(hidden_size, vocab_size)
    
    def forward(self, features, captions):
        # features: (batch, 512, 1, 1) -> (batch, 1, 512)
        features = features.view(features.size(0), 1, -1)
        embeddings = self.embed(captions[:, :-1]) # (batch, seq_len-1, embed_size)
        inputs = torch.cat((features, embeddings), 1) # (batch, seq_len, embed_size)
        hiddens, _ = self.gru(inputs)
        outputs = self.linear(hiddens)
        return outputs

    def sample(self, features, max_len=20, vocab=None):
        sampled_ids = []
        states = None
        inputs = features.view(features.size(0), 1, -1)
        for i in range(max_len):
            hiddens, states = self.gru(inputs, states)
            outputs = self.linear(hiddens.squeeze(1))
            _, predicted = outputs.max(1)
            sampled_ids.append(predicted.item())
            inputs = self.embed(predicted).unsqueeze(1)
            if predicted.item() == 2: # <EOS>
                break
        return sampled_ids

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[.5], std=[.5])
    ])
    
    dataset = ReportDataset(split='train', transform=transform)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True, collate_fn=collate_fn)
    
    encoder = get_resnet_encoder().to(device)
    encoder.eval() # Keep encoder fixed
    
    vocab_size = len(dataset.vocab)
    decoder = DecoderRNN(embed_size=512, hidden_size=512, vocab_size=vocab_size).to(device)
    
    criterion = nn.CrossEntropyLoss(ignore_index=0)
    optimizer = optim.Adam(decoder.parameters(), lr=0.001)
    
    epochs = 5
    print("Training decoder for report generation...")
    for epoch in range(1, epochs + 1):
        total_loss = 0
        for imgs, reports, lengths in dataloader:
            imgs, reports = imgs.to(device).float(), reports.to(device)
            with torch.no_grad():
                features = encoder(imgs)
            
            outputs = decoder(features, reports)
            loss = criterion(outputs.view(-1, vocab_size), reports.view(-1))
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(f"Epoch {epoch}, Loss: {total_loss/len(dataloader):.4f}")

    # Generate some reports
    print("\nGenerating reports for test samples:")
    test_dataset = ReportDataset(split='test', transform=transform)
    for i in range(5):
        img, _ = test_dataset[i]
        label = test_dataset.dataset[i][1][0]
        img_tensor = img.to(device).unsqueeze(0).float()
        with torch.no_grad():
            features = encoder(img_tensor)
            sampled_ids = decoder.sample(features, vocab=dataset.vocab)
        
        report = []
        for word_id in sampled_ids:
            word = dataset.inv_vocab[word_id]
            if word == "<EOS>": break
            if word != "<SOS>": report.append(word)
        
        print(f"Sample {i} (Label {label}): {' '.join(report)}")

if __name__ == "__main__":
    main()

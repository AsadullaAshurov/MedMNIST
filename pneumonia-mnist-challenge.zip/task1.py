import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
import torchvision.models as models
import medmnist
from medmnist import INFO, Evaluator
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, roc_auc_score
from captum.attr import LayerGradCam

def get_resnet18(num_classes=1):
    model = models.resnet18(pretrained=False)
    # Change first conv layer to accept 1 channel
    model.conv1 = nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1, bias=False)
    # Remove initial maxpool as images are already small (28x28)
    model.maxpool = nn.Identity()
    # Change final layer
    if num_classes == 1:
        model.fc = nn.Linear(model.fc.in_features, 1)
    else:
        model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model

def train(model, device, train_loader, optimizer, criterion):
    model.train()
    total_loss = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device).float(), target.to(device).float()
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(train_loader)

def test(model, device, test_loader, criterion):
    model.eval()
    test_loss = 0
    all_targets = []
    all_outputs = []
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device).float(), target.to(device).float()
            output = model(data)
            test_loss += criterion(output, target).item()
            all_targets.append(target.cpu().numpy())
            all_outputs.append(torch.sigmoid(output).cpu().numpy())
    
    all_targets = np.concatenate(all_targets)
    all_outputs = np.concatenate(all_outputs)
    auc = roc_auc_score(all_targets, all_outputs)
    accuracy = np.mean((all_outputs > 0.5) == all_targets)
    
    return test_loss / len(test_loader), accuracy, auc, all_targets, all_outputs

def main():
    data_flag = 'pneumoniamnist'
    info = INFO[data_flag]
    DataClass = getattr(medmnist, info['python_class'])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Transforms
    data_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[.5], std=[.5])
    ])

    # Datasets
    train_dataset = DataClass(split='train', transform=data_transform, download=True)
    val_dataset = DataClass(split='val', transform=data_transform, download=True)
    test_dataset = DataClass(split='test', transform=data_transform, download=True)

    train_loader = DataLoader(dataset=train_dataset, batch_size=128, shuffle=True)
    val_loader = DataLoader(dataset=val_dataset, batch_size=128, shuffle=False)
    test_loader = DataLoader(dataset=test_dataset, batch_size=128, shuffle=False)

    model = get_resnet18().to(device)
    # Since classes are imbalanced, we can use pos_weight in BCEWithLogitsLoss
    pos_weight = torch.tensor([1214 / 3494]).to(device) # approximate weight for positive class? 
    # Actually, pos_weight should be num_neg / num_pos
    # Counter({1: 3494, 0: 1214}) -> weight for class 1 should be 1214/3494 ? No, usually it's negative/positive
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight) 
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    epochs = 5
    for epoch in range(1, epochs + 1):
        train_loss = train(model, device, train_loader, optimizer, criterion)
        val_loss, val_acc, val_auc, _, _ = test(model, device, val_loader, criterion)
        print(f"Epoch {epoch}: Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}, Val AUC: {val_auc:.4f}")

    # Final test
    test_loss, test_acc, test_auc, targets, outputs = test(model, device, test_loader, criterion)
    print(f"Test Loss: {test_loss:.4f}, Test Acc: {test_acc:.4f}, Test AUC: {test_auc:.4f}")

    # Confusion Matrix
    cm = confusion_matrix(targets, outputs > 0.5)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=info['label'].values())
    disp.plot()
    plt.savefig('confusion_matrix.png')
    plt.close()

    # Save model
    torch.save(model.state_dict(), 'resnet18_pneumonia.pth')
    print("Model saved as resnet18_pneumonia.pth")

    # Grad-CAM
    layer_gc = LayerGradCam(model, model.layer4)
    
    # Pick a few samples from test set
    samples_idx = [0, 1, 2, 3, 4]
    fig, axes = plt.subplots(len(samples_idx), 2, figsize=(10, 5 * len(samples_idx)))
    for i, idx in enumerate(samples_idx):
        img_tensor, target = test_dataset[idx]
        img_tensor = img_tensor.to(device).unsqueeze(0).float()
        img_tensor.requires_grad = True
        
        attr = layer_gc.attribute(img_tensor, target=0) # target is binary, so target=0 refers to the output
        upsampled_attr = LayerGradCam.interpolate(attr, (28, 28))
        
        # Original image
        img_np = img_tensor.squeeze().detach().cpu().numpy()
        axes[i, 0].imshow(img_np, cmap='gray')
        axes[i, 0].set_title(f"Target: {target[0]} (0:Normal, 1:Pneumonia)")
        axes[i, 0].axis('off')
        
        # Heatmap
        heatmap = upsampled_attr.squeeze().detach().cpu().numpy()
        axes[i, 1].imshow(img_np, cmap='gray')
        axes[i, 1].imshow(heatmap, cmap='jet', alpha=0.5)
        axes[i, 1].set_title("Grad-CAM")
        axes[i, 1].axis('off')
        
    plt.savefig('grad_cam_samples.png')
    plt.close()
    print("Grad-CAM samples saved as grad_cam_samples.png")

if __name__ == "__main__":
    main()
